%====================================================================================   
%  Simulation results for van der Pol
%====================================================================================
%%
dt = 0.001;
t = 0:dt:30;  
len = length(t); 

x = zeros(3,len);   
v = zeros(3,len);
y_0 = zeros(1,len);   
dy_0= zeros(1,len); 

x(:,1) = [-0.8  2.5 -2 ]';  
v(:,1) = [0    0    0 ]'; 
y_0(1)=1;

aij=3;

C0=2.5;
C1=2.5;
C2=2.5;
C3=2.5;
C0line=2.5*ones(1,len);
C1line=2.5*ones(1,len);
C2line=2.5*ones(1,len);
C3line=2.5*ones(1,len);


f_0 = @(y_0,t) cos(t) + 0.25*cos(0.5*t); 

f1_1 = @(x,v,t)   -v  +x -1/3*x^3 + 1*cos(t);       
f2_1 = @(x,v,t)   ( x +0.7 -0.8*v + 1.5*cos(t) );

g1_1 = @(x,v,t)   v*sin( x * cos(t)  );     
g2_1 = @(x,v,t)   v*cos( x * sin(t)   );  

f1_2 = @(x,v,t)   -v   +x -1/3*x^3 + 0.74*cos(t);   
f2_2 = @(x,v)     0.1*( x +0.7 -0.8*v  );
g1_2 = @(x,v,t)   x*sin( v* cos(t)    );
g2_2 = @(x,v,t)   x*cos( v * sin(t)   );


randn('state',100);  
noise= randn(1,len)';  


sigma = zeros(3,len); 
sigma(:,1) = [0 0 0]';

%%
s10=zeros(1,len); 
e10=zeros(1,len);
s13=zeros(1,len);
e13=zeros(1,len);

s20=zeros(1,len);
e20=zeros(1,len); 

s31=zeros(1,len);     
e31=zeros(1,len);         

ei=zeros(3,len); 

z1=zeros(3,len); 
z2=zeros(3,len);

xi1=zeros(3,len);   
xi2=zeros(3,len); 

Z1=zeros(3,len); 
Z2=zeros(3,len);

Upsilon=zeros(3,len); 
varpi=zeros(3,len);
Pi=zeros(3,len);


Theta1_1=zeros(5,len);  
Theta1_2=zeros(5,len); 
Theta1_3=zeros(5,len); 

Theta2_1=zeros(5,len);   
Theta2_2=zeros(5,len); 
Theta2_3=zeros(5,len); 


W1_1=zeros(5,len);  
W1_2=zeros(5,len);
W1_3=zeros(5,len);

W2_1=zeros(5,len);  
W2_2=zeros(5,len);
W2_3=zeros(5,len);


W1=zeros(3,len);  
W2=zeros(3,len); 
Theta1=zeros(3,len);  
Theta2=zeros(3,len); 
M1=zeros(3,len);  
M2=zeros(3,len);



Theta1_1_fcn=zeros(3,len);     
W1_1S=zeros(3,len);
Theta2_2_fcn=zeros(3,len);       
W2_2S=zeros(3,len);

test1=zeros(3,len);   
test2=zeros(3,len);   

test3=zeros(3,len);   
test4=zeros(3,len);   

daleth1=zeros(3,len);  
daleth2=zeros(3,len);

Z1M=zeros(3,len);  
Z2M=zeros(3,len); 



alfa1=zeros(3,len);
balfa1=zeros(3,len); 
zeta=zeros(3,len);

P1=zeros(3,len); 
Q1=zeros(3,len); 

u=zeros(3,len);  
w=zeros(3,len);  

c1 = [30 30 30]';  
c2 = [10 10 10]';

K=0.01;   

xi1(:,1) = [0 0 0]'; 
xi2(:,1) = [0 0 0]';


p1=[2 2 2]'; 
p2=[2 2 2]'; 

W1(:,1)= [0 0 0]';  
W2(:,1)= [0 0 0]'; 
Theta1(:,1)= [0 0 0]'; 
Theta2(:,1)= [0 0 0]'; 
M2(:,1)= [0 0 0]'; 

P1(:,1)= [0 0 0]'; 
Q1(:,1)= [0 0 0]'; 

tau=0.002;  

vM= [150 200 200]';  

sW1=[1 0.01 0.1 ]'; 
sW2=[0.01 0.01 0.01 ]';
sth1=[0.5 0.5 0.1 ]';
sth2=[1 1 1 ]'; 
sm1=[0.3 0.01 0.05 ]';
sm2=[0.02 0.01 0.01 ]';

sigW1=[1 1 1]';  
sigW2=[0.5 1 1]';
sigtheta1=[0.1 0.5 0.5]';
sigtheta2=[1 2 1]';
sigM1=[0.8 1 1]';
sigM2=[2 1 1]';


sP1=[10 10 10]';
sQ1=[10 10 10 ]';

sigP1=[2 3 1]';
sigQ1=[5 5 5]';



a=2;  
d=1;  
funch = @(t) 20*( 1-(d/a)*t )^a + 0.3;    

h = zeros(1,len);
barh=zeros(1,len);   
underh=zeros(1,len);  

Dbarfunch = @(t)   20*a *(1-(d/a)*t) *(-(d/a));   
Dbarh=zeros(1,len);  
Dunderfunch = @(t) 20*a *(1-(d/a)*t) *(-(d/a));  
Dunderh=zeros(1,len);  



%%
for i = 1:len-1   

        
        if  i < (a/d)* 1/dt 
             h(i)=funch(t(i));
        else
             h(i)=0.3;
        end
       
        barh(i)=0.7*h(i);   
        underh(i)=0.7*h(i);
        
         if   i < (a/d)* 1/dt    
              Dbarh(i)   = Dbarfunch( t(i) );   
              Dunderh(i) = Dunderfunch( t(i) );
         else
             Dbarh(i)   = 0;
             Dunderh(i) = 0;
         end

      
         dy_0(i)= f_0( y_0(i),t(i) );
         y_0(i+1) = y_0(i) + dt*(      dy_0(i)       );  
         
     
    for j = 1
          
              
               s10(i)=( x(1,i)-y_0(i) )/C0;
               e10(i)=log(   (1+s10(i))/(1-s10(i))    );
               
               s13(i)=( x(1,i)-x(3,i) )/C3;
               e13(i)=log(   (1+s13(i))/(1-s13(i))    );

               ei(j,i)=aij*e10(i) + aij*e13(i);    

              
               z1(j,i)= (   underh(i)*barh(i)*ei(j,i)    )/(   (underh(i)+ei(j,i))*(barh(i)-ei(j,i))     );
               
               
              
               if i > 1
                  xi1(j,i)=xi1(j,i-1)+ dt*(     xi2(j,i-1) -p1(j)*xi1(j,i-1)       ); 
               end
               Z1(j,i)=z1(j,i) - xi1(j,i);

             
               Upsilon(j,i)= (  barh(i)*underh(i)*( barh(i)*underh(i) +ei(j,i)^2 )   )/(     (underh(i)+ei(j,i))^2*(barh(i)-ei(j,i))^2     );
               varpi(j,i)=  2*aij / ( (1-s10(i)^2)*C0 )  + 2*aij / ( (1-s13(i)^2)*C3 );    
               Pi(j,i)=(  barh(i)*ei(j,i)^2   )/(   (underh(i)+ei(j,i))^2*(barh(i)-ei(j,i))  ) *Dunderh(i)   + (   -underh(i)*ei(j,i)^2     )/(   (underh(i)+ei(j,i))*(barh(i)-ei(j,i))^2    )  *Dbarh(i);

              
               Theta1_1_fcn(j,i)= Theta1_1(:,i)'*fcn(t(i));    
               W1_1S(j,i)= W1_1(:,i)'* S4(x(j,i),x(3,i),y_0(i),Theta1_1_fcn(j,i)); 
               
               test1(j,i)= norm(      fcn(t(i))'* W1_1(:,i).*dotS(  S4(x(j,i),x(3,i),y_0(i),Theta1_1_fcn(j,i)),  Theta1_1_fcn(j,i)  )       )^2;
               test2(j,i)= norm(      dotS( S4(x(j,i),x(3,i),y_0(i),Theta1_1_fcn(j,i)),Theta1_1_fcn(j,i) )   *Theta1_1_fcn(j,i)             )^2;
               daleth1(j,i)=  sqrt(   1 + test1(j,i) +  test2(j,i)    ); 
               Z1M(j,i)= (  Z1(j,i)^3*M1(j,i)^2*daleth1(j,i)^2 ) /(  abs(Z1(j,i)^3)*M1(j,i)*daleth1(j,i) + K  );
               
               alfa1(j,i)= c1(j)*Z1(j,i)*(  Upsilon(j,i)*varpi(j,i)  )^(-1)   +3/2*Z1(j,i)*(  Upsilon(j,i)*varpi(j,i)  )^(1/3)   +(  Upsilon(j,i)*varpi(j,i)  )^(-1)*  (  Pi(j,i)+ W1_1S(j,i)+  Z1M(j,i)  );

              
               if i==1    
                  balfa1(j,i)=alfa1(j,i);   
               else
                  balfa1(j,i)= balfa1(j,i-1) + dt*(     -zeta(j,i-1)/tau   -( zeta(j,i-1)^3*P1(j,i-1)^2 ) / ( abs(zeta(j,i-1)^3)*P1(j,i-1)+K )     - 3/2*( zeta(j,i-1)*Q1(j,i-1)^2 ) / ( zeta(j,i-1)^2*Q1(j,i-1)+K )          );
               end
               zeta(j,i) = balfa1(j,i)-alfa1(j,i);
               z2(j,i)=v(j,i)- balfa1(j,i);

               if i > 1
                   xi2(j,i)=xi2(j,i-1)+ dt*(       u(j,i-1)-w(j,i-1) - p2(j)* xi2(j,i-1)       ); 
               end
               Z2(j,i)= z2(j,i) - xi2(j,i);

              
               Theta2_2_fcn(j,i)= Theta2_1(:,i)'*fcn(t(i));  
               W2_2S(j,i)= W2_1(:,i)'* S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) );
                      
               test3(j,i) = norm(       fcn(t(i))'* W2_1(:,i).* dotS(  S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ),Theta2_2_fcn(j,i)   )     )^2;
               test4(j,i) = norm(       dotS(  S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ),Theta2_2_fcn(j,i)   )  * Theta2_2_fcn(j,i)        )^2;
               daleth2(j,i)=  sqrt(   1 + test3(j,i) +  test4(j,i)    ); 
               Z2M(j,i)= (  Z2(j,i)^3*M2(j,i)^2*daleth2(j,i)^2 ) /(  abs(Z2(j,i)^3)*M2(j,i)*daleth2(j,i) + K  );
               
               w(j,i)= -c2(j)*Z2(j,i) -1/4*Z2(j,i) - W2_2S(j,i) -Z2M(j,i);  

               
               if abs(w(j,i)) / vM(j) <= 1
                  u(j,i)=w(j,i);
               else
                  u(j,i)=sign(w(j,i))*vM(j);
               end


              
              if ((2*1/dt <= i) && (i < 6*1/dt))   ||  ((15*1/dt <= i) &&  (i < 25*1/dt))  || ((28*1/dt <= i) && (i< 31*1/dt))  
               
                sigma(j,i)=1;  
                x(j,i+1) = x(j,i) + dt*(   f1_1(x(j,i),v(j,i),t(i))     +    g1_1( x(j,i),v(j,i),t(i) )*noise(i)  )     ;                
                v(j,i+1) = v(j,i) + dt*(   f2_1(x(j,i),v(j,i),t(i))  +u(j,i)   +  g2_1( x(j,i),v(j,i),t(i) )*noise(i) )     ; 
              else
                
                sigma(j,i)=2;
                x(j,i+1) = x(j,i) + dt*(   f1_2(x(j,i),v(j,i),t(i))      +  g1_2( x(j,i),v(j,i),t(i) )*noise(i) )    ;                
                v(j,i+1) = v(j,i) + dt*(   f2_2(x(j,i),v(j,i))  +u(j,i)   +  g2_2( x(j,i),v(j,i),t(i) )*noise(i))    ; 
              end
              sigma(j,len)=1;  

              
               W1_1(:,i+1) = W1_1(:,i) + dt*(     sW1(j)* Z1(j,i)^3*  (  S4(x(j,i),x(3,i),y_0(i),Theta1_1_fcn(j,i)) - dotS( S4(x(j,i), x(3,i) ,y_0(i), Theta1_1_fcn(j,i)),Theta1_1_fcn(j,i)) * Theta1_1_fcn(j,i)  )       - sigW1(j)* W1_1(:,i)       ); 
               W2_1(:,i+1) = W2_1(:,i) + dt*(     sW2(j)* Z2(j,i)^3*  (  S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) )      - dotS( S3(x(j,i),v(j,i),Theta2_2_fcn(j,i)),Theta2_2_fcn(j,i) )          * Theta2_2_fcn(j,i)  )       - sigW2(j)* W2_1(:,i)       );

               Theta1_1(:,i+1) = Theta1_1(:,i) + dt*(   sth1(j)*Z1(j,i)^3*  fcn(t(i))'* W1_1(:,i).* dotS(S4(x(j,i), x(3,i) ,y_0(i), Theta1_1_fcn(j,i)),Theta1_1_fcn(j,i))     - sigtheta1(j) *  Theta1_1(:,i)       );  
               Theta2_1(:,i+1) = Theta2_1(:,i) + dt*(   sth2(j)*Z2(j,i)^3*  fcn(t(i))'* W2_1(:,i).* dotS(S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ),Theta2_2_fcn(j,i))             - sigtheta2(j) *  Theta2_1(:,i)       ); 

               Theta1(j,i+1) = norm( Theta1_1(:,i+1) ); 
               Theta2(j,i+1) = norm( Theta2_1(:,i+1) );
               
               W1(j,i+1)= norm(  W1_1(:,i+1)  );
               W2(j,i+1)= norm(  W2_1(:,i+1)  );
               
               M1(j,i+1) = M1(j,i) + dt*(    sm1(j)*abs(Z1(j,i)^3) *daleth1(j,i)   - sigM1(j)* M1(j,i)      ); 
               M2(j,i+1) = M2(j,i) + dt*(    sm2(j)*abs(Z2(j,i)^3) *daleth2(j,i)   - sigM2(j)* M2(j,i)      );


               P1(j,i+1) = P1(j,i) + dt*(            sP1(j)*abs(zeta(j,i)^3) -sigP1(j)*P1(j,i)        );
               Q1(j,i+1) = Q1(j,i) + dt*(        3/2*sQ1(j)*zeta(j,i)^2      -sigQ1(j)*Q1(j,i)        );



                
    end
    

   for j = 2
              
              
               s20(i)=( x(2,i)-y_0(i) )/C0;
               e20(i)=log(    ( 1+s20(i) )/( 1-s20(i) )    );
               
               ei(j,i)=aij*e20(i);

               
               z1(j,i)= (   underh(i)*barh(i)*ei(j,i)    )/(   (underh(i)+ei(j,i))*(barh(i)-ei(j,i))     );

               
               if i > 1
                   xi1(j,i)=xi1(j,i-1)+ dt*(     xi2(j,i-1) -p1(j)*xi1(j,i-1)       );  
               end
               Z1(j,i)=z1(j,i) - xi1(j,i);

              
               Upsilon(j,i)= (  barh(i)*underh(i)*( barh(i)*underh(i) +ei(j,i)^2 )   )/(    (underh(i)+ei(j,i))^2*(barh(i)-ei(j,i))^2   );
               varpi(j,i)=   2*aij / ( (1- s20(i)^2)*C0 ); 
               Pi(j,i)=(  barh(i)*ei(j,i)^2   )/(   (underh(i)+ei(j,i))^2*(barh(i)-ei(j,i))  ) *Dunderh(i)   + (   -underh(i)*ei(j,i)^2     )/(   (underh(i)+ei(j,i))*(barh(i)-ei(j,i))^2    )  *Dbarh(i);

               
               Theta1_1_fcn(j,i)= Theta1_2(:,i)'*fcn(t(i));
               W1_1S(j,i)= W1_2(:,i)'* S3( x(j,i),y_0(i),Theta1_1_fcn(j,i)); 
               
               test1(j,i)= norm(       fcn(t(i))'* W1_2(:,i).* dotS( S3( x(j,i),y_0(i),Theta1_1_fcn(j,i)), Theta1_1_fcn(j,i) )        )^2;
               test2(j,i)= norm(       dotS( S3( x(j,i),y_0(i),Theta1_1_fcn(j,i)), Theta1_1_fcn(j,i) )  * Theta1_1_fcn(j,i)           )^2;
               daleth1(j,i)=  sqrt(   1 + test1(j,i) +  test2(j,i)    ); 
               Z1M(j,i)= (  Z1(j,i)^3*M1(j,i)^2*daleth1(j,i)^2 ) /(  abs(Z1(j,i)^3)*M1(j,i)*daleth1(j,i) + K  );

               alfa1(j,i)= c1(j)*Z1(j,i)*(  Upsilon(j,i)*varpi(j,i)  )^(-1)  +3/2*Z1(j,i)*(  Upsilon(j,i)*varpi(j,i)  )^(1/3)   +(  Upsilon(j,i)*varpi(j,i)  )^(-1)*  (  Pi(j,i)+ W1_1S(j,i)+  Z1M(j,i)  );
               
               
               if i==1    
                  balfa1(j,i)=alfa1(j,i);   
               else
                  balfa1(j,i)= balfa1(j,i-1) + dt*(     -zeta(j,i-1)/tau   -( zeta(j,i-1)^3*P1(j,i-1)^2 ) / ( abs(zeta(j,i-1)^3)*P1(j,i-1)+K )     - 3/2*( zeta(j,i-1)*Q1(j,i-1)^2 ) / ( zeta(j,i-1)^2*Q1(j,i-1)+K )          );
               end
               zeta(j,i) = balfa1(j,i)-alfa1(j,i);
               z2(j,i)=v(j,i)- balfa1(j,i);

               if i > 1
               xi2(j,i)=xi2(j,i-1)+ dt*(       u(j,i-1)-w(j,i-1)- p2(j)* xi2(j,i-1)       );  
               end
               Z2(j,i)= z2(j,i) - xi2(j,i);
              

               
               Theta2_2_fcn(j,i)= Theta2_2(:,i)'*fcn(t(i));
               W2_2S(j,i)= W2_2(:,i)'* S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) );
                      
               test3(j,i) = norm(       fcn(t(i))'* W2_2(:,i).* dotS(  S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ),Theta2_2_fcn(j,i)  )      )^2;
               test4(j,i) = norm(       dotS(   S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ),Theta2_2_fcn(j,i)   ) * Theta2_2_fcn(j,i)        )^2;
               daleth2(j,i)=  sqrt(   1 + test3(j,i) +  test4(j,i)    ); 
               Z2M(j,i)= (  Z2(j,i)^3*M2(j,i)^2*daleth2(j,i)^2 ) /(  abs(Z2(j,i)^3)*M2(j,i)*daleth2(j,i) + K  );
               
               w(j,i)= -c2(j)*Z2(j,i) -1/4*Z2(j,i) - W2_2S(j,i) -Z2M(j,i);  


              
               if abs(w(j,i)) / vM(j) < 1
                  u(j,i)=w(j,i);
               else
                  u(j,i)=sign(w(j,i))*vM(j);
               end

               
                if ((1*1/dt <= i) && (i < 5*1/dt))   ||  ((10*1/dt <= i) &&  (i < 15*1/dt))   ||  ( (20*1/dt <= i) && (i< 25*1/dt) )   
                    
                    sigma(j,i)=1;
                    x(j,i+1) = x(j,i) + dt*(   f1_1(x(j,i),v(j,i),t(i))    +  g1_1( x(j,i),v(j,i),t(i) )*noise(i)   )     ;                
                    v(j,i+1) = v(j,i) + dt*(   f2_1(x(j,i),v(j,i),t(i))  +u(j,i)   +  g2_1( x(j,i),v(j,i),t(i) )*noise(i) )    ; 
               else
                    
                    sigma(j,i)=2;
                   x(j,i+1) = x(j,i) + dt*(   f1_2(x(j,i),v(j,i),t(i))    +  g1_2( x(j,i),v(j,i),t(i) )*noise(i)   )    ;                
                   v(j,i+1) = v(j,i) + dt*(   f2_2(x(j,i),v(j,i))  +u(j,i)   +  g2_2( x(j,i),v(j,i),t(i) )*noise(i))    ; 
               end
               sigma(j,len)=2;  

               
               W1_2(:,i+1) = W1_2(:,i) + dt*(             sW1(j)*Z1(j,i)^3*  (     S3( x(j,i),y_0(i),Theta1_1_fcn(j,i)) - dotS( S3( x(j,i),y_0(i),Theta1_1_fcn(j,i)) , Theta1_1_fcn(j,i) ) * Theta1_1_fcn(j,i)  )  - sigW1(j)* W1_2(:,i)    ); 
               W2_2(:,i+1) = W2_2(:,i) + dt*(             sW2(j)*Z2(j,i)^3*  (     S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) )- dotS( S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ),Theta2_2_fcn(j,i))   *  Theta2_2_fcn(j,i) )  - sigW2(j)* W2_2(:,i)    );

               Theta1_2(:,i+1) = Theta1_2(:,i) + dt*(      sth1(j)*Z1(j,i)^3*  fcn(t(i))* W1_2(:,i).'* dotS( S3( x(j,i),y_0(i),Theta1_1_fcn(j,i)), Theta1_1_fcn(j,i) ) - sigtheta1(j) *  Theta1_2(:,i)      ); 
               Theta2_2(:,i+1) = Theta2_2(:,i) + dt*(      sth2(j)*Z2(j,i)^3*  fcn(t(i))* W2_2(:,i).'* dotS( S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ),Theta2_2_fcn(j,i) ) - sigtheta1(j) *  Theta2_2(:,i)      ); 

               
               Theta1(j,i+1) = norm( Theta1_2(:,i+1) ); 
               Theta2(j,i+1) = norm( Theta2_2(:,i+1) );
               
               W1(j,i+1)= norm(  W1_2(:,i+1) );
               W2(j,i+1)= norm(  W2_2(:,i+1) );
               
               M1(j,i+1) = M1(j,i) + dt*(            sm1(j)*abs(Z1(j,i)^3)*daleth1(j,i)   - sigM1(j)* M1(j,i)      ); 
               M2(j,i+1) = M2(j,i) + dt*(            sm2(j)*abs(Z2(j,i)^3)*daleth2(j,i)   - sigM2(j)* M2(j,i)      );

               P1(j,i+1) = P1(j,i) + dt*(            sP1(j)*abs(zeta(j,i)^3) -sigP1(j)*P1(j,i)        );
               Q1(j,i+1) = Q1(j,i) + dt*(        3/2*sQ1(j)*zeta(j,i)^2      -sigQ1(j)*Q1(j,i)        );
             
   end


     for j = 3
         
     
              
               s31(i)=( x(3,i)-x(1,i) )/C1;
               e31(i)=log( ( 1+s31(i) )/( 1-s31(i) )  );
               
               ei(j,i)=aij*e31(i);

               
               z1(j,i)= (   underh(i)*barh(i)*ei(j,i)    )/(   (underh(i)+ei(j,i))*(barh(i)-ei(j,i))     );


               
               if i > 1
                   xi1(j,i)=xi1(j,i-1)+ dt*(     xi2(j,i-1) -p1(j)*xi1(j,i-1)       );  
               end
               Z1(j,i)=z1(j,i) - xi1(j,i);

              
               Upsilon(j,i)= (  barh(i)*underh(i)*( barh(i)*underh(i) +ei(j,i)^2 )   )/(    (underh(i)+ei(j,i))^2*(barh(i)-ei(j,i))^2   );
               varpi(j,i)=  2*aij / ( (1- s31(i)^2)*C1  ); 
               Pi(j,i)=(  barh(i)*ei(j,i)^2   )/(   (underh(i)+ei(j,i))^2*(barh(i)-ei(j,i))  ) *Dunderh(i)   + (   -underh(i)*ei(j,i)^2     )/(   (underh(i)+ei(j,i))*(barh(i)-ei(j,i))^2    )  *Dbarh(i);

               
               Theta1_1_fcn(j,i)= Theta1_3(:,i)'*fcn(t(i)); 
               W1_1S(j,i)= W1_3(:,i)'* S3( x(j,i),x(1,i),Theta1_1_fcn(j,i)  ); 
               
               test1(j,i)= norm(      fcn(t(i))'* W1_3(:,i).* dotS( S3( x(j,i),x(1,i),Theta1_1_fcn(j,i)  ), Theta1_1_fcn(j,i) )        )^2;
               test2(j,i)= norm(      dotS( S3( x(j,i),x(1,i),Theta1_1_fcn(j,i)  ), Theta1_1_fcn(j,i) )   * Theta1_1_fcn(j,i)          )^2;
               daleth1(j,i)=  sqrt(   1 + test1(j,i) +  test2(j,i)    ); 
               Z1M(j,i)= (  Z1(j,i)^3*M1(j,i)^2*daleth1(j,i)^2 ) /(  abs(Z1(j,i)^3)*M1(j,i)*daleth1(j,i) + K  );

               alfa1(j,i)= c1(j)*Z1(j,i)*(  Upsilon(j,i)*varpi(j,i)  )^(-1)  +3/2*Z1(j,i)*(  Upsilon(j,i)*varpi(j,i)  )^(1/3)   +(  Upsilon(j,i)*varpi(j,i)  )^(-1)*  (  Pi(j,i)+ W1_1S(j,i)+  Z1M(j,i)  );
               
               
               if i==1    
                  balfa1(j,i)=alfa1(j,i);   
               else
                  balfa1(j,i)= balfa1(j,i-1) + dt*(     -zeta(j,i-1)/tau   -( zeta(j,i-1)^3*P1(j,i-1)^2 ) / ( abs(zeta(j,i-1)^3)*P1(j,i-1)+K )     - 3/2*( zeta(j,i-1)*Q1(j,i-1)^2 ) / ( zeta(j,i-1)^2*Q1(j,i-1)+K )          );
               end
               zeta(j,i) = balfa1(j,i)-alfa1(j,i);
               z2(j,i)=v(j,i)- balfa1(j,i);

               if i > 1
                    xi2(j,i)=xi2(j,i-1)+ dt*(       u(j,i-1)-w(j,i-1)- p2(j)* xi2(j,i-1)       );  
               end
               Z2(j,i)= z2(j,i) - xi2(j,i);
               
               
               Theta2_2_fcn(j,i)= Theta2_3(:,i)'*fcn(t(i)); 
               W2_2S(j,i)= W2_3(:,i)'* S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ); 
                      
               test3(j,i) = norm(       fcn(t(i))'* W2_3(:,i).* dotS(  S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ),Theta2_2_fcn(j,i)   )     )^2;
               test4(j,i) = norm(       dotS(   S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ),Theta2_2_fcn(j,i)   ) * Theta2_2_fcn(j,i)        )^2;
               daleth2(j,i)=  sqrt(   1 + test3(j,i) +  test4(j,i)    ); 
               Z2M(j,i)= (  Z2(j,i)^3*M2(j,i)^2*daleth2(j,i)^2 ) /(  abs(Z2(j,i)^3)*M2(j,i)*daleth2(j,i) + K  );
               
               w(j,i)= -c2(j)*Z2(j,i) -1/4*Z2(j,i) - W2_2S(j,i) -Z2M(j,i);  

               
               if abs(w(j,i)) / vM(j) < 1
                  u(j,i)=w(j,i);
               else
                  u(j,i)=sign(w(j,i))*vM(j);
               end

              
              if  ((0*1/dt <= i) &&  (i < 4*1/dt))   ||   ((12*1/dt <= i) && (i< 20*1/dt))   ||  ((28*1/dt <= i) && (i< 33*1/dt))   
                    
                    sigma(j,i)=1;
                    x(j,i+1) = x(j,i) + dt*(   f1_1(x(j,i),v(j,i),t(i))       +  g1_1( x(j,i),v(j,i),t(i) )*noise(i)  )   ;                
                v(j,i+1) = v(j,i) + dt*(   f2_1(x(j,i),v(j,i),t(i))  +u(j,i)  +  g2_1( x(j,i),v(j,i),t(i) )*noise(i) )     ; 
             else
                     
                    sigma(j,i)=2;
                    x(j,i+1) = x(j,i) + dt*(   f1_2(x(j,i),v(j,i),t(i))      +  g1_2( x(j,i),v(j,i),t(i) )*noise(i) )    ;                
                    v(j,i+1) = v(j,i) + dt*(   f2_2(x(j,i),v(j,i))  +u(j,i)  +  g2_2( x(j,i),v(j,i),t(i) )*noise(i))     ; 
             end
             sigma(j,len)=1;  

             
               W1_3(:,i+1) = W1_3(:,i) + dt*(      sW1(j)*Z1(j,i)^3*(    S3( x(j,i),x(1,i),Theta1_1_fcn(j,i)  )- dotS(   S3( x(j,i),x(1,i),Theta1_1_fcn(j,i)  ), Theta1_1_fcn(j,i)   ) *  Theta1_1_fcn(j,i)  )    - sigW1(j)* W1_3(:,i)    ); 
               W2_3(:,i+1) = W2_3(:,i) + dt*(      sW2(j)*Z2(j,i)^3*(    S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ) - dotS(   S3( x(j,i),v(j,i),Theta2_2_fcn(j,i) ),Theta2_2_fcn(j,i)   )   *  Theta2_2_fcn(j,i)  )    - sigW2(j)* W2_3(:,i)    );

               Theta1_3(:,i+1) = Theta1_3(:,i) + dt*(           sth1(j)*Z1(j,i)^3*fcn(t(i))'* W1_3(:,i).* dotS(   S3( x(j,i),x(1,i),Theta1_1_fcn(j,i)  ), Theta1_1_fcn(j,i)   )  - sigtheta1(j) *  Theta1_3(:,i)      ); 
               Theta2_3(:,i+1) = Theta2_3(:,i) + dt*(           sth2(j)*Z2(j,i)^3*fcn(t(i))'* W2_3(:,i).* dotS(   S3( x(j,i),v(j,i),Theta2_2_fcn(j,i)  ), Theta2_2_fcn(j,i)   )  - sigtheta2(j) *  Theta2_3(:,i)       ); 

               Theta1(j,i+1) = norm( Theta1_3(:,i+1) );
               Theta2(j,i+1) = norm( Theta2_3(:,i+1) );
               
               W1(j,i+1)= norm(  W1_3(:,i+1) );
               W2(j,i+1)= norm(  W2_3(:,i+1) );
               
               M1(j,i+1) = M1(j,i) + dt*(      sm1(j)*abs(Z1(j,i)^3)*daleth1(j,i)   - sigM1(j)* M1(j,i)      ); 
               M2(j,i+1) = M2(j,i) + dt*(      sm2(j)*abs(Z2(j,i)^3)*daleth2(j,i)   - sigM2(j)* M2(j,i)      );

               P1(j,i+1) = P1(j,i) + dt*(            sP1(j)*abs(zeta(j,i)^3) -sigP1(j)*P1(j,i)        );
               Q1(j,i+1) = Q1(j,i) + dt*(        3/2*sQ1(j)*zeta(j,i)^2      -sigQ1(j)*Q1(j,i)        );
          
    end
          
end


%%
figure(1) 
subplot(3,1,1)
plot(t,sigma(1,:),'b','LineWidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('${\sigma_1(t)}$','Interpreter','latex','fontsize',15)
axis([0 30 0 2.7])

subplot(3,1,2)
plot(t,sigma(2,:),'b','LineWidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('${\sigma_2(t)}$','Interpreter','latex','fontsize',15)
axis([0 30 0 2.7])

subplot(3,1,3)
plot(t,sigma(3,:),'b','LineWidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('${\sigma_3(t)}$','Interpreter','latex','fontsize',15)
axis([0 30 0 2.7])


figure(2)
plot(t,x(1,:),'-.r',t,x(2,:),'b',t,x(3,:),'--b','LineWidth',1);
hold on
plot(t,y_0,'k','LineWidth',1);
xlabel('time(sec)','fontsize',12);
ylabel('$y_i,y_0,i=1,2,3$','Interpreter','latex','fontsize',16);
h=legend('${y_1}$','${y_2}$','${y_3}$', '${y_0}$','NumColumns',4); 
set(h,'Interpreter','latex','fontsize',16)


figure(3)
subplot(3,1,1)
plot(t,barh, '-.r', 'linewidth',1);
hold on
plot(t,ei(1,:),'b', 'linewidth',1);
hold on 
plot(t,-underh,'--r', 'linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('${e_1}$','Interpreter','latex','fontsize',15)
h=legend('${ \bar h(t)}$','${ e_{1}}$','${ -\underline h(t)}$','NumColumns',3);     
set(h,'Interpreter','latex','fontsize',15)

subplot(3,1,2)
plot(t,barh, '-.r', 'linewidth',1);
hold on
plot(t,ei(2,:),'b', 'linewidth',1);
hold on 
plot(t,-underh,'--r', 'linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('${e_2}$','Interpreter','latex','fontsize',15)
h=legend('${ \bar h(t)}$','${ e_{2}}$','${ -\underline h(t)}$','NumColumns',3);     
set(h,'Interpreter','latex','fontsize',15)

subplot(3,1,3)
plot(t,barh, '-.r', 'linewidth',1);
hold on
plot(t,ei(3,:),'b', 'linewidth',1);
hold on 
plot(t,-underh,'--r', 'linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('${e_3}$','Interpreter','latex','fontsize',15)
h=legend('${ \bar h(t)}$','${ e_{3}}$','${ -\underline h(t)}$','NumColumns',3);      
set(h,'Interpreter','latex','fontsize',15)


figure(4)
subplot(3,1,1)
plot( t, C0line,'-.r', 'linewidth',1);
hold on
plot( t, abs( x(1,:)-y_0 ),'b','linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('$ R_0,|y_1-y_0|$','Interpreter','latex','fontsize',15)
axis([0 30 0 5])
h=legend('${R_0}$','${|y_1-y_0|}$','NumColumns',2);
set(h,'Interpreter','latex','fontsize',15)

subplot(3,1,2)
plot(t,C0line, '-.r','linewidth',1);
hold on 
plot(t,abs( x(2,:)-y_0 ),'b','linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('$R_0,|y_2-y_0|$','Interpreter','latex','fontsize',15)
axis([0 30 0 5])
h=legend('${R_0}$','${|y_2-y_0|}$','NumColumns',2);
set(h,'Interpreter','latex','fontsize',15)

subplot(3,1,3)
plot(t,C3line, '-.r','linewidth',1);
hold on
plot(t,abs( x(1,:)-x(3,:) ),'b','linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('$R_3,|y_1-y_3|$','Interpreter','latex','fontsize',15)
axis([0 30 0 5])
h=legend('${R_3}$','${|y_1-y_3|} $','NumColumns',2);
set(h,'Interpreter','latex','fontsize',15)


figure(5)
subplot(3,1,1)
plot(t,w(1,:),'--r','linewidth',1);
hold on 
plot(t,u(1,:),'b','linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('${v_1,u_1}$','Interpreter','latex','fontsize',15);
h=legend('${v_1}$','${u_1}$','NumColumns',2);  
set(h,'Interpreter','latex','fontsize',15)

subplot(3,1,2)
plot(t,w(2,:),'--r','linewidth',1);
hold on 
plot(t,u(2,:),'b','linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('${v_2,u_2}$','Interpreter','latex','fontsize',15);
h=legend('${v_2}$','${u_2}$','NumColumns',2);  
set(h,'Interpreter','latex','fontsize',15)

subplot(3,1,3)
plot(t,w(3,:),'--r','linewidth',1);
hold on 
plot(t,u(3,:),'b','linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('${v_3,u_3}$','Interpreter','latex','fontsize',15);
h=legend('${v_3}$','${u_3}$','NumColumns',2);    
set(h,'Interpreter','latex','fontsize',15)

















