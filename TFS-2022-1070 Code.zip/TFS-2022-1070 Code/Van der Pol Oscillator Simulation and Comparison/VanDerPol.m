%====================================================================================   
%  Simulation results for the chaotic attractor of van der Pol
%====================================================================================

dt = 0.001;
t = 0:dt:600;       
len = length(t); 

x = zeros(1,len);  
v = zeros(1,len);
x(:,1) = -1;  
v(:,1) = -0.2; 
 
f{1} = @(x,v,t)  -v + x -1/3*x^3 + 0.74*cos(t); 
f{2} = @(x,v)  0.1*( x +0.7 -0.8*v );

for i = 1:len-1 

                x(i+1) = x(i) + dt*(   f{1}(x(i),v(i),t(i))        );                
                v(i+1) = v(i) + dt*(   f{2}(x(i),v(i))             );  
end


figure(1) 
plot(x,v,'b','LineWidth',1);  
xlabel('${\psi_1}$','Interpreter','latex','fontsize',16);
ylabel('${\psi_2}$','Interpreter','latex','fontsize',16);  







