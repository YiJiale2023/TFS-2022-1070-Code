%====================================================================================   
%  Compare Simulation results for Deterministic  
%====================================================================================
%%
dt = 0.001;
t = 0:dt:30;  
len = length(t); 

x = zeros(3,len);   
v = zeros(3,len);
y_0 = zeros(1,len);  
dy_0= zeros(1,len); 



y_0(1)=1;
x(:,1) = [-0.8  2.5 -2 ]';  
v(:,1) = [0    0    0 ]'; 


aij=3;  

C0=2.5;
C1=2.5;
C2=2.5;
C3=2.5;
C0line=2.5*ones(1,len);
C1line=2.5*ones(1,len);
C2line=2.5*ones(1,len);
C3line=2.5*ones(1,len);

f_0 = @(y_0,t) cos(t) + 0.25*cos(0.5*t); 

f1_1 = @(x,v,t)   -v  +x -1/3*x^3 + 1*cos(t)  ;    
f2_1 = @(x,v,t)   ( x +0.7 -0.8*v + 1.5*cos(t) ); 


%%
s10=zeros(1,len); 
e10=zeros(1,len);
s13=zeros(1,len);
e13=zeros(1,len);

s20=zeros(1,len);    
e20=zeros(1,len); 

s31=zeros(1,len);        
e31=zeros(1,len);         



z1=zeros(3,len); 
z2=zeros(3,len);

tau=0.002;  

alfa1=zeros(3,len);
balfa1=zeros(3,len); 
u=zeros(3,len); 





N1 = ones(3,len);   
k1 = zeros(3,len);   
k1(:,1) = [0 0 0]';  

N2 = ones(3,len);   
k2 = zeros(3,len);   
k2(:,1) = [0 0 0]';  

Upsilon=zeros(3,len); 



W1_1=zeros(5,len);  
W1_2=zeros(5,len);
W1_3=zeros(5,len);

W2_1=zeros(5,len);  
W2_2=zeros(5,len);
W2_3=zeros(5,len);


W1_1S=zeros(3,len); 
W2_2S=zeros(3,len);



zeta=zeros(3,len); 


W1=zeros(3,len); 
W2=zeros(3,len); 
W1(:,1)= [0 0 0]';   
W2(:,1)= [0 0 0]'; 


sW1=[0.01 0.01 0.01]';  
sW2=[0.01 0.01 0.01]';

sigW1=[1 1 1]';  
sigW2=[1 1 1]';


b1 = [1.4 1.4 1.4]';  
b2 = [1.4 1.4 1.4]';


%% 
for i = 1:len-1   


        
         dy_0(i)= f_0( y_0(i),t(i) ); 
         y_0(i+1) = y_0(i) + dt*(      dy_0(i)       );
         
     
    for j = 1
          
               
               s10(i)=( x(1,i)-y_0(i) )/C0;
               e10(i)=log(   (1+s10(i))/(1-s10(i))    );
               
               s13(i)=( x(1,i)-x(3,i) )/C3;
               e13(i)=log(   (1+s13(i))/(1-s13(i))    );

               z1(j,i)=aij*e10(i) + aij*e13(i);    

              
               
               
               N1(j,i)= exp(k1(j,i)^2)*cos(pi*0.5*k1(j,i));   
               Upsilon(j,i)= (2*aij) / (  C0*( 1-s10(i)^2 ) )   +  (2*aij) / (  C3*( 1-s13(i)^2 ) );
               W1_1S(j,i)= W1_1(:,i)'* S5( x(j,i),x(3,i),v(3,i),y_0(i),dy_0(i) );   
              
               alfa1(j,i)= -N1(j,i)*1/Upsilon(j,i) * (  b1(j)*z1(j,i) + W1_1S(j,i)  ); 


             
               if i==1    
                  balfa1(j,i)=alfa1(j,i);   
               else
                  balfa1(j,i)= balfa1(j,i-1) + dt*(     -zeta(j,i-1)/tau  ); 
               end
               zeta(j,i) = balfa1(j,i)-alfa1(j,i); 
               
               z2(j,i)=v(j,i)- balfa1(j,i);


            
              N2(j,i)= exp(k2(j,i)^2)*cos(pi*0.5*k2(j,i));   
              W2_2S(j,i)= W2_1(:,i)'* S5( x(j,i),v(j,i),balfa1(j,i),z1(j,i),z2(j,i));    
              u(j,i)=N2(j,i)*(   b2(j)*z2(j,i) +  W2_2S(j,i)    );


                    
              x(j,i+1) = x(j,i) + dt*(   f1_1(x(j,i),v(j,i),t(i))       );                
              v(j,i+1) = v(j,i) + dt*(   f2_1(x(j,i),v(j,i),t(i))  +u(j,i)   );
            

              
               W1_1(:,i+1) = W1_1(:,i) + dt*(     sW1(j)* z1(j,i)*S5( x(j,i),x(3,i),v(3,i),y_0(i),dy_0(i) )       - sW1(j)*sigW1(j)* W1_1(:,i)       ); 
               W2_1(:,i+1) = W2_1(:,i) + dt*(     sW2(j)* z2(j,i)*S5( x(j,i),v(j,i),balfa1(j,i),z1(j,i),z2(j,i))  - sW2(j)*sigW2(j)* W2_1(:,i)       );

               W1(j,i+1)= norm(  W1_1(:,i+1)  );
               W2(j,i+1)= norm(  W2_1(:,i+1)  );

               k1(j,i+1) = k1(j,i) + dt*(  0.2*b1(j)*z1(j,i)^2 + 0.2*z1(j,i)*W1_1S(j,i)   );   
               k2(j,i+1) = k2(j,i) + dt*(  0.2*b2(j)*z2(j,i)^2 + 0.2*z2(j,i)*W2_2S(j,i)   );
             
               
            
                
    end
    

   for j = 2
              
             
               s20(i)=( x(2,i)-y_0(i) )/C0;
               e20(i)=log(    ( 1+s20(i) )/( 1-s20(i) )    );
               
               z1(j,i)=aij*e20(i);

               
               
               
               N1(j,i)= exp(k1(j,i)^2)*cos(pi*0.5*k1(j,i));   
               Upsilon(j,i)= (2*aij) / (  C0*( 1-s20(i)^2 ) );
               W1_1S(j,i)= W1_2(:,i)'* S3( x(j,i),y_0(i),dy_0(i) );    
              
               alfa1(j,i)= -N1(j,i)*1/Upsilon(j,i) * (  b1(j)*z1(j,i) + W1_1S(j,i)  );


           
               if i==1    
                  balfa1(j,i)=alfa1(j,i);   
               else
                  balfa1(j,i)= balfa1(j,i-1) + dt*(     -zeta(j,i-1)/tau  ); 
               end
               zeta(j,i) = balfa1(j,i)-alfa1(j,i); 
               
               z2(j,i)=v(j,i)- balfa1(j,i);


             
              N2(j,i)= exp(k2(j,i)^2)*cos(pi*0.5*k2(j,i));  
              W2_2S(j,i)= W2_2(:,i)'* S5( x(j,i),v(j,i),balfa1(j,i),z1(j,i),z2(j,i));   
              u(j,i)=N2(j,i)*(   b2(j)*z2(j,i) +  W2_2S(j,i)    );


                           
              x(j,i+1) = x(j,i) + dt*(   f1_1(x(j,i),v(j,i),t(i))       );                
              v(j,i+1) = v(j,i) + dt*(   f2_1(x(j,i),v(j,i),t(i))  +u(j,i)   );
               
              
               W1_2(:,i+1) = W1_2(:,i) + dt*(     sW1(j)* z1(j,i)*S3( x(j,i),y_0(i),dy_0(i) )      - sW1(j)*sigW1(j)* W1_2(:,i)       ); 
               W2_2(:,i+1) = W2_2(:,i) + dt*(     sW2(j)* z2(j,i)*S5( x(j,i),v(j,i),balfa1(j,i),z1(j,i),z2(j,i))  - sW2(j)*sigW2(j)* W2_2(:,i)       );

               W1(j,i+1)= norm(  W1_2(:,i+1)  );
               W2(j,i+1)= norm(  W2_2(:,i+1)  );

               k1(j,i+1) = k1(j,i) +   dt*(  0.2*b1(j)*z1(j,i)^2 + 0.2*z1(j,i)*W1_1S(j,i)   ); 
               k2(j,i+1) = k2(j,i) +   dt*(  0.2*b2(j)*z2(j,i)^2 + 0.2*z2(j,i)*W2_2S(j,i)   ); 
 

              
             
   end


     for j = 3
         
     
             
               s31(i)=( x(3,i)-x(1,i) )/C1;
               e31(i)=log( ( 1+s31(i) )/( 1-s31(i) )  );
               
               z1(j,i)=aij*e31(i);

               

             
               
               N1(j,i)= exp(k1(j,i)^2)*cos(pi*0.5*k1(j,i));   
               Upsilon(j,i)= (2*aij) / (  C1*( 1-s31(i)^2 ) );
               W1_1S(j,i)= W1_3(:,i)'* S3( x(j,i),x(1,i),v(1,i));    
              
               alfa1(j,i)= -N1(j,i)*1/Upsilon(j,i) * (  b1(j)*z1(j,i) + W1_1S(j,i)  );


              
               if i==1    
                  balfa1(j,i)=alfa1(j,i);   
               else
                  balfa1(j,i)= balfa1(j,i-1) + dt*(     -zeta(j,i-1)/tau  ); 
               end
               zeta(j,i) = balfa1(j,i)-alfa1(j,i); 
               
               z2(j,i)=v(j,i)- balfa1(j,i);


             
              N2(j,i)= exp(k2(j,i)^2)*cos(pi*0.5*k2(j,i));  
              W2_2S(j,i)= W2_3(:,i)'* S5( x(j,i),v(j,i),balfa1(j,i),z1(j,i),z2(j,i));   
              u(j,i)=N2(j,i)*(   b2(j)*z2(j,i) +  W2_2S(j,i)    );

                       
              x(j,i+1) = x(j,i) + dt*(   f1_1(x(j,i),v(j,i),t(i))       );                
              v(j,i+1) = v(j,i) + dt*(   f2_1(x(j,i),v(j,i),t(i))  +u(j,i)   );

            
               W1_3(:,i+1) = W1_3(:,i) + dt*(     sW1(j)* z1(j,i)*S3( x(j,i),y_0(i),dy_0(i) )      - sW1(j)*sigW1(j)* W1_3(:,i)       ); 
               W2_3(:,i+1) = W2_3(:,i) + dt*(     sW2(j)* z2(j,i)*S5( x(j,i),v(j,i),balfa1(j,i),z1(j,i),z2(j,i))  - sW2(j)*sigW2(j)* W2_3(:,i)       );

               W1(j,i+1)= norm(  W1_3(:,i+1)  );
               W2(j,i+1)= norm(  W2_3(:,i+1)  );

               k1(j,i+1) = k1(j,i) +   dt*(  0.2*b1(j)*z1(j,i)^2   + 0.2*z1(j,i)*W1_1S(j,i)   ); 
               k2(j,i+1) = k2(j,i) +   dt*(  0.2*b2(j)*z2(j,i)^2   + 0.2*z2(j,i)*W2_2S(j,i)   ); 
               
    end
          
end



%%
figure(1)
subplot(4,1,1)
plot(t,x(1,:),'-.r',t,x(2,:),'b',t,x(3,:),'--b','LineWidth',1);
hold on
plot(t,y_0,'k','LineWidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('$y_i,y_0,i=1,2,3$','Interpreter','latex','fontsize',15);
h=legend('${y_1}$','${y_2}$','${y_3}$', '${y_0}$','NumColumns',4); 
set(h,'Interpreter','latex','fontsize',15)


subplot(4,1,2)
plot( t, C0line,'-.r', 'linewidth',1);
hold on
plot( t, abs( x(1,:)-y_0 ),'b','linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('$ R_0,|y_1-y_0|$','Interpreter','latex','fontsize',15)
axis([0 30 0 5])
h=legend('${R_0}$','${|y_1-y_0|}$','NumColumns',2);
set(h,'Interpreter','latex','fontsize',15)

subplot(4,1,3)
plot(t,C0line, '-.r','linewidth',1);
hold on 
plot(t,abs( x(2,:)-y_0 ),'b','linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('$R_0,|y_2-y_0|$','Interpreter','latex','fontsize',15)
axis([0 30 0 5])
h=legend('${R_0}$','${|y_2-y_0|}$','NumColumns',2);
set(h,'Interpreter','latex','fontsize',15)

subplot(4,1,4)
plot(t,C3line, '-.r','linewidth',1);
hold on
plot(t,abs( x(1,:)-x(3,:) ),'b','linewidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('$R_3,|y_1-y_3|$','Interpreter','latex','fontsize',15)
axis([0 30 0 5])
h=legend('${R_3}$','${|y_1-y_3|} $','NumColumns',2);
set(h,'Interpreter','latex','fontsize',15)














