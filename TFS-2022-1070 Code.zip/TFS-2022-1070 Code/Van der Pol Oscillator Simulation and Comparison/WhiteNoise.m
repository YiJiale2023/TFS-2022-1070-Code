%====================================================================================   
%  Simulation for the used White Noise
%====================================================================================

dt = 0.03;
t = 0:dt:30;  
len = length(t); 

%randn('state',100);  
noise= randn(1,len)';  

figure(1)   
plot(t,noise,'b','LineWidth',1);
xlabel('time(sec)','fontsize',11);
ylabel('${noise}$','Interpreter','latex','fontsize',15)
%h=legend('${noise}$');
%set(h,'Interpreter','latex','fontsize',15)


